from tkinter import *
import pygame
import sys
import time
import os


root = Tk()
root.title("OS")
root.geometry("{0}x{1}+0+0".format(root.winfo_screenwidth(), root.winfo_screenheight()))
root.overrideredirect(True)
pygame.mixer.init()

def Openprogram1():
       os.system('start cmd /K "python programme\ProgrammSlot1\main.py"')


def Openprogram2():
       os.system('start cmd /K "python programme\ProgrammSlot2\main.py"')


def Openprogram3():
       os.system('start cmd /K "python programme\ProgrammSlot3\main.py"')


def Openprogram4():
       os.system('start cmd /K "python programme\ProgrammSlot4\main.py"')


def Openprogram5():
       os.system('start cmd /K "python programme\ProgrammSlot5\main.py"')

def Openprogram6():
       os.system('start cmd /K "python programme\ProgrammSlot6\main.py"')


def Openprogram6():
       os.system('start cmd /K "python programme\ProgrammSlot7\main.py"')


def programmBar():
       image2 = PhotoImage(file='assets/images/chrome.png')
       chromecast = Label(image=image2)
       chromecast.place(y = -150, x = 0)
       programmChoice = Label(text="Program Choice").place(y=300, x=800)
       ButtonProgramm1 = Button(text="Programm1", command=Openprogram1).place(y= 500, x=800)
       ButtonProgramm2 = Button(text="Programm2", command=Openprogram2).place(y=500, x=900)
       ButtonProgramm3 = Button(text="Programm3", command=Openprogram3).place(y=500, x=1000)
       ButtonProgramm4 = Button(text="Programm4", command=Openprogram4).place(y=600, x=800)
       ButtonProgramm5 = Button(text="Programm5", command=Openprogram5).place(y=600, x=900)
       ButtonProgramm6 = Button(text="Programm6", command=Openprogram6).place(y=600, x=1000)

       
       






def prop():
       bgc2 = PhotoImage(file="assets/images/propN.png")
       bgcl2 = Label() 
       bgcl2.image = bgc2
       bgcl2['image'] = bgcl2.image
       bgcl2.place(x = 850, y = 150)

game = Label()
#bglc = PhotoImage(file="assets/images/background2.png")
#bgl = Label() 
#bgl.image = bglc
#bgl['image'] = bgl.image
#bgl.place(x=0, y=-150)
root.image = PhotoImage(file='assets/images/background2.png')
bg_logo = Label(root, image=root.image)
bg_logo.place(x=0, y=-150)

def start():
    root.image = PhotoImage(file='assets/images/background2.png')
    bg_logo = Label(root, image=root.image)
    bg_logo.place(x=0, y=-150)
    game = Label()





P = 0
BG = Button()

def plus():
       global P
       P+=1
       p = Label(text=P)
       p.place(y = 305, x = 855)
       p.config(fg='cyan')
       p.config(bg='blue')
       
def music_on():
       pygame.mixer.music.load("assets/songs/MusicAulocia.mp3")
       pygame.mixer.music.play()
       
def fault():
       global P
       P = 0
       
       
def test():
        bb = Button(text="Click me!!", command = plus, bg='red', fg='yellow', activeforeground='red', activebackground='yellow').place(y = 300, x = 1000)
        bgc = PhotoImage(file="assets/images/Clicker.png")
        bgcl = Label() 
        bgcl.image = bgc
        bgcl['image'] = bgcl.image
        bgcl.place(x = 850, y = 150)
        bbg = Button(text='default', command = fault).place(y = 300, x = 900)
        #bb.config()
        #bb.config()
        
def settings():
       imageS2 = PhotoImage(file='assets/images/settings.png')
       settings = Label()
       settings.image = imageS2
       settings['image'] = settings.image
       settings.place(y = 0,  x = 150)
       music = Button(text = "Music On", command = music_on).place(y = 0,  x = 150)
       Button(text = "PROPERTYS", command = prop, bg='yellow', fg = 'blue', activeforeground='yellow',activebackground='blue').place(y = 300, x = 900)
       
def menu():
       bgc3 = PhotoImage(file="assets/images/menu.png")
       bgcl3 = Label() 
       bgcl3.image = bgc3
       bgcl3['image'] = bgcl3.image
       bgcl3.place(x = 0, y = 500)
       bs = Button(text = "settings", command = settings).place(y = 500, x = 0)
       exitButton= Button(text="Exit", command=exit, fg = 'blue', bg='yellow').place(y= 800, x= 300)
       
       
     
       
        


bt = Button(text="start", command = menu)
l = Label(text="Search")
G = Button(text="", command = test)
bt.place(y = 950, x = 0)


menu = Button(text="close", command = start, bg = 'red', fg = 'blue', activeforeground = 'blue', activebackground = 'red').place(y = 950, x = 1850)


def test2():
       image2 = PhotoImage(file='assets/images/chrome.png')
       chromecast = Label(image=image2)
       chromecast.place(y = -150, x = 0)
       e = Entry().place(y = 310, x = 490)
       b = Button(text="ENTER", activeforeground = 'cyan', activebackground = 'blue', bg = 'cyan', fg = 'blue').place(y = 345, x = 550)
       url = Button(text="Search").place(y = 150, x = 560)
       Label(text="Google", bg = 'cyan', font = 'Arial 25', fg = 'blue').place(y = 200, x = 510)
       



def UpdateTheTime():
       seconds=time.time()
       TIME3=time.ctime(seconds)
       timeBar = Label(root, text=TIME3).place(y = 1000, x = 1700)

ch = Button(command = test2)
seconds=time.time()
TIME3 = time.ctime(seconds)
       

timeBar = Label(text=TIME3).place(y = 1000, x = 1700)
Update = Button(text="Update the Time!!", command=UpdateTheTime).place(y = 1000, x = 1500)
image2 = PhotoImage(file='assets/images/gameIcon.png')
G.config(image=image2)
bt.config(compound='top')
ch.place(y = 900, x = 170)
image = PhotoImage(file='assets/images/chromeIcon.png')
ch.config(image=image)
bt.config(width = 10, height = 3)
bt.config(font = 'Arial 9')
bt.config(bg = 'lime')
bt.config(activebackground = 'green')
G.place(y = 900, x = 300)
bt.config(activeforeground = 'cyan')

#Programms
imageProgramm = PhotoImage(file='assets/images/software.png')
ProgrammButton = Button(image=imageProgramm, command=programmBar).place(y = 900, x = 450)






           
root.mainloop()