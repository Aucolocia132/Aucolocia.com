from tkinter import *
from mainOS import *

root = Tk()
menubar = Menu(root)


root.mainloop()